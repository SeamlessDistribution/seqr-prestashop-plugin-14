<?php
$_seqr_lib_dir=dirname(__FILE__);

require_once($_seqr_lib_dir.'/prestashop/PsConfig.php');
require_once($_seqr_lib_dir.'/prestashop/PsFactory.php');
require_once($_seqr_lib_dir.'/prestashop/PsSeqrService.php');
require_once($_seqr_lib_dir.'/prestashop/PsSeqrFrontController.php');

