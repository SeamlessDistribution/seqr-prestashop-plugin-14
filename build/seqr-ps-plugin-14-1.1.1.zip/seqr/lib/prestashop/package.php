<?php

$_seqr_lib_dir=dirname(__FILE__);

require_once($_seqr_lib_dir . '/PsConfig.php');
require_once($_seqr_lib_dir . '/PsFactory.php');
require_once($_seqr_lib_dir . '/PsSeqrService.php');
require_once($_seqr_lib_dir . '/PsSeqrFrontController.php');

